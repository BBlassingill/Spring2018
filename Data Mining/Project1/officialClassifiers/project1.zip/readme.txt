How to run code:

Execute the following command in a terminal in the same directory of the project: python crossValidation.py > output.txt

Any output from the execution of the code will be saved into a text file named output.txt.
This output will contain the results of each executed task:
Task A - the predicted labels
Task B - the accuracies for each classifier
Task C/D - the accuracies for each Centroid split